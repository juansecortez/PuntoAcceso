

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid mt--6">
            <div class="row">
                <div class="col-xl-12 order-xl-1">
                    <div class="card">
                        <div class="card-header">
                            <div class="row align-items-center">
                                <div class="col-8">
                                    <h3 class="mb-0"><?php echo e(__('Administración de Puertas')); ?></h3>
                                </div>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Puerta::class)): ?>
                                    <div class="col-4 text-right">
                                        <button class="btn btn-sm btn-success" data-toggle="modal" data-target="#assignModal">
                                            <i class="fa fa-star fa-spin"></i> <?php echo e(__('Asignar Puertas')); ?>

                                        </button>
                                        <a href="<?php echo e(route('puertas.create')); ?>" class="btn btn-sm btn-primary"> <?php echo e(__('Agregar Puerta')); ?></a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-12 mt-2">
                            <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('alerts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="table-responsive py-4" id="puertas-table">
                            <table class="table align-items-center table-flush">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col"><?php echo e(__('Nombre Puerta')); ?></th>
                                        <th scope="col"><?php echo e(__('Latitud')); ?></th>
                                        <th scope="col"><?php echo e(__('Longitud')); ?></th>
                                        <th scope="col"><?php echo e(__('Tipo')); ?></th>
                                       
                                        <th scope="col"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $puertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $puerta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($puerta->NombrePuerta); ?></td>
                                            <td><?php echo e($puerta->latitude); ?></td>
                                            <td><?php echo e($puerta->longitud); ?></td>
                                            <td><?php echo e($puerta->Tipo); ?></td>
                                            
                                            <td class="text-right">
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-empleados', App\Empleado::class)): ?>
                                                    <div class="dropdown">
                                                        <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            <i class="nc-icon nc-bullet-list-67"></i>
                                                        </a>
                                                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                                            <a class="dropdown-item" href="<?php echo e(route('puertas.edit', $puerta->id)); ?>"><?php echo e(__('Editar')); ?></a>
                                                            <form action="<?php echo e(route('puertas.destroy', $puerta->id)); ?>" method="POST" style="display:inline-block;">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button type="submit" class="dropdown-item" onclick="return confirm('<?php echo e(__('¿Estás seguro de que deseas eliminar esta puerta?')); ?>')"><?php echo e(__('Eliminar')); ?></button>
                                                            </form>
                                                            <a class="dropdown-item" href="<?php echo e(route('puertas.assign_empleados', $puerta->id)); ?>"><?php echo e(__('Asignar Empleados')); ?></a>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="assignModal" tabindex="-1" role="dialog" aria-labelledby="assignModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form method="post" action="<?php echo e(route('puertas.assign_selected_to_all')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="assignModalLabel"><?php echo e(__('Asignar Puertas a los Empleados')); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="select-all"><?php echo e(__('Seleccionar Todas')); ?></label>
                            <input type="checkbox" id="select-all">
                        </div>
                        <?php $__currentLoopData = $puertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $puerta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group">
                                <input type="checkbox" name="puertas[]" value="<?php echo e($puerta->id); ?>" class="puerta-checkbox">
                                <label><?php echo e($puerta->NombrePuerta); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Cerrar')); ?></button>
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Asignar')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.getElementById('select-all').onclick = function() {
        var checkboxes = document.querySelectorAll('.puerta-checkbox');
        for (var checkbox of checkboxes) {
            checkbox.checked = this.checked;
        }
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => __('Administración de Puertas'),
    'class' => '',
    'folderActive' => 'laravel-examples',
    'elementActive' => 'puerta'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\gquiteno\validatooor\resources\views/puertas/index.blade.php ENDPATH**/ ?>