<div class="sidebar" data-color="brown" data-active-color="danger">
    <!--
    Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    -->
    <div class="logo">
        <a class="simple-text logo-mini">
            <div class="logo-image-small">
                <img src="<?php echo e(asset('img/logo-small.png')); ?>">
            </div>
        </a>
        <a class="simple-text logo-normal">
            <?php echo e(__('PUNTOACCESO')); ?>

        </a>
    </div>
    <div class="sidebar-wrapper">
        <div class="user">
            <div class="photo">
                <?php if(isset(auth()->user()->picture)): ?>
                    <img src="<?php echo e(asset(auth()->user()->picture)); ?>">
                <?php else: ?>
                    <img class="avatar border-gray" src="<?php echo e(asset('img/No Profile Picture.png')); ?>" alt="...">
                <?php endif; ?>
            </div>
            <div class="info">
                <a data-toggle="collapse" href="#collapseExample" class="collapsed">
                    <span>
                        <?php echo e(auth()->user()->name); ?>

                    <b class="caret"></b>
                    </span>
                </a>
                <div class="clearfix"></div>
                <div class="collapse <?php echo e($folderActive == 'profile' ? 'show' : ''); ?>" id="collapseExample">
                    <ul class="nav">
                        <li class="<?php echo e($elementActive == 'edit-profile' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('profile.edit')); ?>">
                                <span class="sidebar-mini-icon"><?php echo e(__('MP')); ?></span>
                                <span class="sidebar-normal"><?php echo e(__('Mi Perfil')); ?></span>
                            </a>
                        </li>
                        <li>
                            <form class="dropdown-item" action="<?php echo e(route('logout')); ?>" id="formLogOutSidebar" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                            <a onclick="document.getElementById('formLogOutSidebar').submit();">
                                <span class="sidebar-mini-icon"><?php echo e(__('CS')); ?></span>
                                <span class="sidebar-normal"><?php echo e(__('Cerrar sesión')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <ul class="nav">
            <li class="<?php echo e($elementActive == 'dashboard' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('home')); ?>">
                    <i class="nc-icon nc-world-2"></i>
                    <p><?php echo e(__('Dashboard')); ?></p>
                </a>
                <a href="<?php echo e(route('uso_puerta.index')); ?>">
                    <i class="nc-icon nc-world-2"></i>
                    <p><?php echo e(__('Reporte de checadas')); ?></p>
                </a>
            </li>
            <li class="<?php echo e($folderActive == 'laravel-examples' ? 'active' : ''); ?>">
                <a data-toggle="collapse" aria-expanded="true" href="#laravelExamples">
                <i class="nc-icon nc-briefcase-24"></i>
                    <p>
                            <?php echo e(__('Utilidades')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse show" id="laravelExamples">
                    <ul class="nav">
                        <li class="<?php echo e($elementActive == 'profile' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('profile.edit')); ?>">
                                <span class="sidebar-mini-icon"><?php echo e(__('M')); ?></span>
                                <span class="sidebar-normal"><?php echo e(__(' Mi Perfil ')); ?></span>
                            </a>
                        </li>
                        <?php if(Auth::user()->role_id == 1): ?>
                            <li class="<?php echo e($elementActive == 'role' ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('page.index', 'role')); ?>">
                                    <span class="sidebar-mini-icon"><?php echo e(__('R')); ?></span>
                                    <span class="sidebar-normal"><?php echo e(__(' Administración de Roles ')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(Auth::user()->role_id == 1): ?>
                            <li class="<?php echo e($elementActive == 'user' ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('page.index', 'user')); ?>">
                                    <span class="sidebar-mini-icon"><?php echo e(__('U')); ?></span>
                                    <span class="sidebar-normal"><?php echo e(__(' Administración de Usuarios ')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <li class="<?php echo e($elementActive == 'contratos' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('page.index', 'contrato')); ?>">
                                <span class="sidebar-mini-icon"><?php echo e(__('C')); ?></span>
                                <span class="sidebar-normal"><?php echo e(__(' Contratos ')); ?></span>
                            </a>
                        </li>
                            <li class="<?php echo e($elementActive == 'empleados' ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('page.index', 'empleado')); ?>">
                                    <span class="sidebar-mini-icon"><?php echo e(__('E')); ?></span>
                                    <span class="sidebar-normal"><?php echo e(__(' Empledos ')); ?></span>
                                </a>
                            </li>
                       
                        
                            <li class="<?php echo e($elementActive == 'puertas' ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('page.index', 'puertas')); ?>">
                                    <span class="sidebar-mini-icon"><?php echo e(__('P')); ?></span>
                                    <span class="sidebar-normal"><?php echo e(__(' Puertas ')); ?></span>
                                </a>
                            </li>
                          
                      
                    </ul>
                </div>
            </li>
           
       </ul>
    </div>
</div><?php /**PATH C:\gquiteno\validatooor\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>