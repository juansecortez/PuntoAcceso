

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid mt--6">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="mb-0"><?php echo e(__('Filtro de Uso de Puertas')); ?></h3>
                        </div>
                        <div class="card-body">
                            <form method="get" action="<?php echo e(route('uso_puerta.index')); ?>">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="FechaInicio"><?php echo e(__('Fecha de Inicio')); ?></label>
                                            <input type="date" name="FechaInicio" id="FechaInicio" class="form-control" value="<?php echo e(request('FechaInicio')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="FechaFin"><?php echo e(__('Fecha de Fin')); ?></label>
                                            <input type="date" name="FechaFin" id="FechaFin" class="form-control" value="<?php echo e(request('FechaFin')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="Contrato"><?php echo e(__('Contrato')); ?></label>
                                            <select name="Contrato" id="Contrato" class="form-control">
                                                <option value=""><?php echo e(__('Seleccione un contrato')); ?></option>
                                                <?php $__currentLoopData = $contratos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($contrato->NoContrato); ?>" <?php echo e(request('Contrato') == $contrato->NoContrato ? 'selected' : ''); ?>>
                                                        <?php echo e($contrato->NoContrato); ?> - <?php echo e($contrato->NombreContrato); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary"><?php echo e(__('Filtrar')); ?></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <?php if(isset($usoPuertas)): ?>
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="mb-0"><?php echo e(__('Uso de Puertas')); ?></h3>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th><?php echo e(__('Nombre')); ?></th>
                                                <th><?php echo e(__('Contrato')); ?></th>
                                                <th><?php echo e(__('Puerta')); ?></th>
                                                <th><?php echo e(__('Tipo')); ?></th>
                                                <th><?php echo e(__('Fecha y Hora')); ?></th>
                                                <th><?php echo e(__('Mapa')); ?></th>
                                                <th><?php echo e(__('Imagen')); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $usoPuertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usoPuerta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($usoPuerta->empleado->Nombre); ?></td>
                                                    <td><?php echo e($usoPuerta->empleado->NoContrato); ?></td>
                                                    <td><?php echo e($usoPuerta->puerta->NombrePuerta); ?></td>
                                                    <td><?php echo e($usoPuerta->puerta->Tipo); ?></td>
                                                    <td><?php echo e($usoPuerta->Fecha); ?></td>
                                                    <td>
                                                        <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#mapModal" onclick="showMap(<?php echo e($usoPuerta->latitude); ?>, <?php echo e($usoPuerta->longitud); ?>)">
                                                            <?php echo e(__('Ver Mapa')); ?>

                                                        </button>
                                                    </td>
                                                    <td>
                                                        <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#imageModal" onclick="showImage('<?php echo e(asset('https://pactral.com/PuntoAcceso/public/' . $usoPuerta->img)); ?>')">
                                                            <?php echo e(__('Ver Foto')); ?>

                                                        </button>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <?php echo e($usoPuertas->links()); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Map Modal -->
    <div class="modal fade" id="mapModal" tabindex="-1" role="dialog" aria-labelledby="mapModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="mapModalLabel"><?php echo e(__('Mapa')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div id="map" style="height: 400px;"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Image Modal -->
    <div class="modal fade" id="imageModal" tabindex="-1" role="dialog" aria-labelledby="imageModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="imageModalLabel"><?php echo e(__('Foto')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body text-center">
                    <img id="modal-image" src="" class="img-fluid" alt="Foto">
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/leaflet@1.7.1/dist/leaflet.js"></script>
    <script>
        function showMap(latitude, longitude) {
            var map = L.map('map').setView([latitude, longitude], 13);

            L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
                maxZoom: 19,
                attribution: '© Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'
            }).addTo(map);

            L.marker([latitude, longitude]).addTo(map);
        }

        function showImage(imageUrl) {
            document.getElementById('modal-image').src = imageUrl;
        }

        document.addEventListener('DOMContentLoaded', function () {
            // Initialize modals and other elements if needed
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', [
    'class' => '',
    'folderActive' => '',
    'elementActive' => 'uso_puerta'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\gquiteno\validatooor\resources\views/uso_puerta/index.blade.php ENDPATH**/ ?>