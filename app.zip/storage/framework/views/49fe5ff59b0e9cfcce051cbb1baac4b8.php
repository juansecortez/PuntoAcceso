<?php if($errors->has($field)): ?>
    <span class="invalid-feedback" role="alert" style="display: block;">
        <strong><?php echo e($errors->first($field)); ?></strong>
    </span>
<?php endif; ?><?php /**PATH C:\gquiteno\validatooor\resources\views/alerts/feedback.blade.php ENDPATH**/ ?>