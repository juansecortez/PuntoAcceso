<footer class="footer footer-black footer-white">
    <div class="container-fluid">
        <div class="row">
           
            <div class="credits ml-auto">
                <span class="copyright">
                    ©
                    <script>
                        document.write(new Date().getFullYear())
                    </script><?php echo e(__(', made  ')); ?><?php echo e(__(' for ')); ?><a class="<?php if(Auth::guest()): ?> text-white <?php endif; ?>"  target="_blank"><?php echo e(__('PUNTOACCESO')); ?></a>
                </span>
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\gquiteno\validatooor\resources\views/layouts/footer.blade.php ENDPATH**/ ?>