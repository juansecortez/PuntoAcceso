

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid mt--6">
            <div class="row">
                <div class="col-xl-12 order-xl-1">
                    <div class="card">
                        <div class="card-header">
                            <div class="row align-items-center">
                                <div class="col-8">
                                    <h3 class="mb-0"><?php echo e(__('Add Puerta')); ?></h3>
                                </div>
                                <div class="col-4 text-right">
                                    <a href="<?php echo e(route('puertas.index')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Regresar a la lista ')); ?></a>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <form method="post" action="<?php echo e(route('puertas.store')); ?>" autocomplete="off">
                                <?php echo csrf_field(); ?>
                                <h6 class="heading-small text-muted mb-4"><?php echo e(__('Información de la puerta')); ?></h6>
                                <div class="pl-lg-4">
                                    <div class="form-group<?php echo e($errors->has('NombrePuerta') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-NombrePuerta"><?php echo e(__('Nombre Puerta')); ?></label>
                                        <input type="text" name="NombrePuerta" id="input-NombrePuerta" class="form-control<?php echo e($errors->has('NombrePuerta') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Nombre Puerta')); ?>" value="<?php echo e(old('NombrePuerta')); ?>" required autofocus>
                                        <?php echo $__env->make('alerts.feedback', ['field' => 'NombrePuerta'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                    <div class="form-group<?php echo e($errors->has('latitude') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-latitude"><?php echo e(__('Latitude')); ?></label>
                                        <input type="text" name="latitude" id="input-latitude" class="form-control<?php echo e($errors->has('latitude') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Latitude')); ?>" value="<?php echo e(old('latitude')); ?>" required>
                                        <?php echo $__env->make('alerts.feedback', ['field' => 'latitude'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                    <div class="form-group<?php echo e($errors->has('longitud') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-longitud"><?php echo e(__('Longitud')); ?></label>
                                        <input type="text" name="longitud" id="input-longitud" class="form-control<?php echo e($errors->has('longitud') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Longitud')); ?>" value="<?php echo e(old('longitud')); ?>" required>
                                        <?php echo $__env->make('alerts.feedback', ['field' => 'longitud'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                    <div class="form-group<?php echo e($errors->has('Tipo') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-Tipo"><?php echo e(__('Tipo')); ?></label>
                                        <select name="Tipo" id="input-Tipo" class="form-control<?php echo e($errors->has('Tipo') ? ' is-invalid' : ''); ?>" required>
                                            <option value="Entrada" <?php echo e(old('Tipo') == 'Entrada' ? 'selected' : ''); ?>>Entrada</option>
                                            <option value="Salida" <?php echo e(old('Tipo') == 'Salida' ? 'selected' : ''); ?>>Salida</option>
                                            <option value="Entrada Comida" <?php echo e(old('Tipo') == 'Entrada comida' ? 'selected' : ''); ?>>Entrada comida</option>
                                            <option value="Salida comida" <?php echo e(old('Tipo') == 'Salida comida' ? 'selected' : ''); ?>>Salida comida</option>
                      
                                        </select>
                                        <?php echo $__env->make('alerts.feedback', ['field' => 'Tipo'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                    <div id="map" style="height: 400px;"></div>
                                    <div class="text-center">
                                        <button type="submit" class="btn btn-success mt-4"><?php echo e(__(' Guardar')); ?></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var map = L.map('map').setView([19.36840142540269, -104.10091443763574], 13); // Inicializa en Minatitlán, Colima, México

        L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
            maxZoom: 19,
            attribution: '© Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'
        }).addTo(map);

        var marker;

        map.on('click', function (e) {
            if (marker) {
                marker.setLatLng(e.latlng);
            } else {
                marker = L.marker(e.latlng).addTo(map);
            }
            document.getElementById('input-latitude').value = e.latlng.lat;
            document.getElementById('input-longitud').value = e.latlng.lng;
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => __('Add Puerta'),
    'class' => '',
    'folderActive' => 'laravel-examples',
    'elementActive' => 'puerta'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\gquiteno\validatooor\resources\views/puertas/create.blade.php ENDPATH**/ ?>