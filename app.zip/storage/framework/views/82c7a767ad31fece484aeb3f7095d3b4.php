<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid mt--6">
            <div class="row">
                <div class="col">
                    <div class="card">
                        <div class="card-header">
                            <div class="row align-items-center">
                                <div class="col-8">
                                    <h3 class="mb-0"><?php echo e(__('Empleados')); ?></h3>
                                  
                                </div>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Empleado::class)): ?>
                                    <div class="col-4 text-right">
                                        <a href="<?php echo e(route('empleado.create')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Agregar empleado')); ?></a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="col-12 mt-2">
                            <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('alerts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>

                        <div class="table-responsive py-4" id="employees-table">
                            <table class="table align-items-center table-flush">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col">Foto</th>
                                        <th scope="col"><?php echo e(__('Nombre')); ?></th>
                                        <th scope="col"><?php echo e(__('Apellido Paterno')); ?></th>
                                        <th scope="col"><?php echo e(__('Apellido Materno')); ?></th>
                                        <th scope="col"><?php echo e(__('Correo')); ?></th>
                                        <th scope="col"><?php echo e(__('CURP')); ?></th>
                                        <th scope="col"><?php echo e(__('Teléfono')); ?></th>
                                        <th scope="col"><?php echo e(__('Número de Contrato')); ?></th>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-empleados', App\Empleado::class)): ?>
                                            <th scope="col"></th>
                                        <?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <span class="avatar avatar-sm rounded-circle">
                                                    <img class="avatar border-gray" src="https://pactral.com/PuntoAcceso/public<?php echo e($empleado->profilePicture()); ?>" alt="...">
                                                </span>
                                            </td>
                                            <td><?php echo e($empleado->Nombre); ?></td>
                                            <td><?php echo e($empleado->ApellidoP); ?></td>
                                            <td><?php echo e($empleado->ApellidoM); ?></td>
                                            <td>
                                                <a href="mailto:<?php echo e($empleado->Correo); ?>"><?php echo e($empleado->Correo); ?></a>
                                            </td>
                                            <td><?php echo e($empleado->CURP); ?></td>
                                            <td><?php echo e($empleado->Telefono); ?></td>
                                            <td><?php echo e($empleado->NoContrato); ?></td>
                                            <td class="text-right">
                                                <?php if(auth()->user()->can('update', $empleado) || auth()->user()->can('delete', $empleado) || auth()->user()->can('assign', $empleado)): ?>
                                                    <div class="dropdown">
                                                        <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            <i class="nc-icon nc-bullet-list-67"></i>
                                                        </a>
                                                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $empleado)): ?>
                                                                <a class="dropdown-item" href="<?php echo e(route('empleado.edit', $empleado)); ?>"><?php echo e(__('Editar')); ?></a>
                                                            <?php endif; ?>
                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $empleado)): ?>
                                                                <form action="<?php echo e(route('empleado.destroy', $empleado)); ?>" method="POST">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('delete'); ?>
                                                                    <button type="button" class="dropdown-item" onclick="confirm('<?php echo e(__('¿Estás seguro de que deseas eliminar este empleado?')); ?>') ? this.parentElement.submit() : ''">
                                                                        <?php echo e(__('Eliminar')); ?>

                                                                    </button>
                                                                </form>
                                                            <?php endif; ?>
                                                            <a class="dropdown-item" href="<?php echo e(route('empleados.assign_puertas', $empleado->id)); ?>"><?php echo e(__('Asignar Puertas')); ?></a>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => __('Administración de Empleados'),
    'class' => '',
    'folderActive' => 'laravel-examples',
    'elementActive' => 'empleado'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\gquiteno\validatooor\resources\views/empleados/index.blade.php ENDPATH**/ ?>