<?php

namespace App\Http\Controllers;

use App\Contrato;
use App\Empleado;
use App\Puerta;
use App\UsoPuerta;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        $contratosCount = Contrato::count();
        $empleadosCount = Empleado::count();
        $puertasEntradaCount = Puerta::where('Tipo', 'Entrada')->count();
        $puertasSalidaCount = Puerta::where('Tipo', 'Salida')->count();

        $usoEntrada = UsoPuerta::select(
            DB::raw('MONTH(Fecha) as mes'),
            DB::raw('COUNT(*) as conteo')
        )
        ->join('puertas', 'uso_puerta.IdPuerta', '=', 'puertas.id')
        ->where('puertas.Tipo', 'Entrada')
        ->groupBy(DB::raw('MONTH(Fecha)'))
        ->pluck('conteo', 'mes');

        $usoSalida = UsoPuerta::select(
            DB::raw('MONTH(Fecha) as mes'),
            DB::raw('COUNT(*) as conteo')
        )
        ->join('puertas', 'uso_puerta.IdPuerta', '=', 'puertas.id')
        ->where('puertas.Tipo', 'Salida')
        ->groupBy(DB::raw('MONTH(Fecha)'))
        ->pluck('conteo', 'mes');

        $empleadosPorContrato = Empleado::select(
            'NoContrato',
            DB::raw('COUNT(*) as conteo')
        )
        ->groupBy('NoContrato')
        ->pluck('conteo', 'NoContrato');

        $usoPuertasPorContrato = UsoPuerta::select(
            'empleados.NoContrato',
            DB::raw('COUNT(*) as conteo')
        )
        ->join('empleados', 'uso_puerta.IdEmpleado', '=', 'empleados.id')
        ->groupBy('empleados.NoContrato')
        ->pluck('conteo', 'empleados.NoContrato');

        return view('dashboard.index', compact(
            'contratosCount', 
            'empleadosCount', 
            'puertasEntradaCount', 
            'puertasSalidaCount', 
            'usoEntrada', 
            'usoSalida', 
            'empleadosPorContrato', 
            'usoPuertasPorContrato'
        ));
    }
}
