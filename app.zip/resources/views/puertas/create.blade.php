@extends('layouts.app', [
    'title' => __('Add Puerta'),
    'class' => '',
    'folderActive' => 'laravel-examples',
    'elementActive' => 'puerta'
])

@section('content')
    <div class="content">
        <div class="container-fluid mt--6">
            <div class="row">
                <div class="col-xl-12 order-xl-1">
                    <div class="card">
                        <div class="card-header">
                            <div class="row align-items-center">
                                <div class="col-8">
                                    <h3 class="mb-0">{{ __('Add Puerta') }}</h3>
                                </div>
                                <div class="col-4 text-right">
                                    <a href="{{ route('puertas.index') }}" class="btn btn-sm btn-primary">{{ __('Regresar a la lista ') }}</a>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <form method="post" action="{{ route('puertas.store') }}" autocomplete="off">
                                @csrf
                                <h6 class="heading-small text-muted mb-4">{{ __('Información de la puerta') }}</h6>
                                <div class="pl-lg-4">
                                    <div class="form-group{{ $errors->has('NombrePuerta') ? ' has-danger' : '' }}">
                                        <label class="form-control-label" for="input-NombrePuerta">{{ __('Nombre Puerta') }}</label>
                                        <input type="text" name="NombrePuerta" id="input-NombrePuerta" class="form-control{{ $errors->has('NombrePuerta') ? ' is-invalid' : '' }}" placeholder="{{ __('Nombre Puerta') }}" value="{{ old('NombrePuerta') }}" required autofocus>
                                        @include('alerts.feedback', ['field' => 'NombrePuerta'])
                                    </div>
                                    <div class="form-group{{ $errors->has('latitude') ? ' has-danger' : '' }}">
                                        <label class="form-control-label" for="input-latitude">{{ __('Latitude') }}</label>
                                        <input type="text" name="latitude" id="input-latitude" class="form-control{{ $errors->has('latitude') ? ' is-invalid' : '' }}" placeholder="{{ __('Latitude') }}" value="{{ old('latitude') }}" required>
                                        @include('alerts.feedback', ['field' => 'latitude'])
                                    </div>
                                    <div class="form-group{{ $errors->has('longitud') ? ' has-danger' : '' }}">
                                        <label class="form-control-label" for="input-longitud">{{ __('Longitud') }}</label>
                                        <input type="text" name="longitud" id="input-longitud" class="form-control{{ $errors->has('longitud') ? ' is-invalid' : '' }}" placeholder="{{ __('Longitud') }}" value="{{ old('longitud') }}" required>
                                        @include('alerts.feedback', ['field' => 'longitud'])
                                    </div>
                                    <div class="form-group{{ $errors->has('Tipo') ? ' has-danger' : '' }}">
                                        <label class="form-control-label" for="input-Tipo">{{ __('Tipo') }}</label>
                                        <select name="Tipo" id="input-Tipo" class="form-control{{ $errors->has('Tipo') ? ' is-invalid' : '' }}" required>
                                            <option value="Entrada" {{ old('Tipo') == 'Entrada' ? 'selected' : '' }}>Entrada</option>
                                            <option value="Salida" {{ old('Tipo') == 'Salida' ? 'selected' : '' }}>Salida</option>
                                            <option value="Entrada Comida" {{ old('Tipo') == 'Entrada comida' ? 'selected' : '' }}>Entrada comida</option>
                                            <option value="Salida comida" {{ old('Tipo') == 'Salida comida' ? 'selected' : '' }}>Salida comida</option>
                      
                                        </select>
                                        @include('alerts.feedback', ['field' => 'Tipo'])
                                    </div>
                                    <div id="map" style="height: 400px;"></div>
                                    <div class="text-center">
                                        <button type="submit" class="btn btn-success mt-4">{{ __(' Guardar') }}</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var map = L.map('map').setView([19.36840142540269, -104.10091443763574], 13); // Inicializa en Minatitlán, Colima, México

        L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
            maxZoom: 19,
            attribution: '© Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'
        }).addTo(map);

        var marker;

        map.on('click', function (e) {
            if (marker) {
                marker.setLatLng(e.latlng);
            } else {
                marker = L.marker(e.latlng).addTo(map);
            }
            document.getElementById('input-latitude').value = e.latlng.lat;
            document.getElementById('input-longitud').value = e.latlng.lng;
        });
    });
</script>

@endsection
